var AWS = require('aws-sdk')
var autoscaling = new AWS.AutoScaling();


exports.handler = (event, context, callback) => {
	var params = {};
	if (event.down) {
		params = {
			AutoScalingGroupName: event.groupName,
			MaxSize: 0,
			DesiredCapacity: 0,
			MinSize: 0
		};
	} else {
		params = {
			AutoScalingGroupName: event.groupName,
			MaxSize: event.MaxSize || 0,
			DesiredCapacity: event.DesiredCapacity || 0,
			MinSize: event.MinSize || 0
		};
	}
	autoscaling.updateAutoScalingGroup(params, function (err, data) {
		if (err) console.log(err, err.stack); // an error occurred
		else console.log(">>>>>>>>>>. Update Instance", data)
		callback(err, data);// successful response
	});
}
